class IrodsError(Exception):
    pass

class IrodsWarning(IrodsError):
    pass
