#ifndef RS_REG_REPLICA_HPP
#define RS_REG_REPLICA_HPP

#include "rcConnect.h"
#include "regReplica.h"


int rsRegReplica( rsComm_t *rsComm, regReplica_t *regReplicaInp );
int _rsRegReplica( rsComm_t *rsComm, regReplica_t *regReplicaInp );

#endif
