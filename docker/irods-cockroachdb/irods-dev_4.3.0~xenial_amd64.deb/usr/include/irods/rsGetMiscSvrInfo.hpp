#ifndef RS_GET_MISC_SVR_INFO_HPP
#define RS_GET_MISC_SVR_INFO_HPP

#include "rcConnect.h"
#include "getMiscSvrInfo.h"

int rsGetMiscSvrInfo( rsComm_t *rsComm, miscSvrInfo_t **outSvrInfo );

#endif
