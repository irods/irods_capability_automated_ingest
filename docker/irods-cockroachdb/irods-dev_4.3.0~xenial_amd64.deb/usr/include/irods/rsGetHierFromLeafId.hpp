#ifndef RS_GET_HIER_FROM_LEAF_ID_HPP
#define RS_GET_HIER_FROM_LEAF_ID_HPP

#include "get_hier_from_leaf_id.h"

int rsGetHierFromLeafId(rsComm_t*,get_hier_inp_t*,get_hier_out_t**);


#endif
