#ifndef RS_BULK_DATA_OBJ_PUT_HPP
#define RS_BULK_DATA_OBJ_PUT_HPP

#include "rodsDef.h"
#include "rcConnect.h"
#include "bulkDataObjPut.h"

int rsBulkDataObjPut(rsComm_t *rsComm, bulkOprInp_t *bulkOprInp, bytesBuf_t *bulkOprInpBBuf);

#endif
