#ifndef OPR_COMPLETE_H__
#define OPR_COMPLETE_H__

#include "rcConnect.h"

int rcOprComplete( rcComm_t *conn, int retval );

#endif
