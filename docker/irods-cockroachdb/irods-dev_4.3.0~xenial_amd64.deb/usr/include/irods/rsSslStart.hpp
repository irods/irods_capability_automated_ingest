#ifndef RS_SSL_START_HPP
#define RS_SSL_START_HPP

#include "rcConnect.h"
#include "sslStart.h"

int rsSslStart( rsComm_t *rsComm, sslStartInp_t *sslStartInp );

#endif
