#ifndef RS_STREAM_CLOSE_HPP
#define RS_STREAM_CLOSE_HPP

#include "rcConnect.h"
#include "fileClose.h"

int rsStreamClose( rsComm_t *rsComm, fileCloseInp_t *fileCloseInp );

#endif
