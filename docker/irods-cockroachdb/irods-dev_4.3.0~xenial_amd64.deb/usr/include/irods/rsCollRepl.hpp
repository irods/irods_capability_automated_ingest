#ifndef RS_COLL_REPL_HPP
#define RS_COLL_REPL_HPP

#include "objInfo.h"
#include "dataObjInpOut.h"
#include "rcConnect.h"

int rsCollRepl( rsComm_t *rsComm, collInp_t *collReplInp, collOprStat_t **collOprStat );

#endif
