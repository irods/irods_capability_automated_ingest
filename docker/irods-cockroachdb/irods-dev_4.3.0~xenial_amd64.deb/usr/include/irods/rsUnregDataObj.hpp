#ifndef RS_UNREG_DATA_OBJ_HPP
#define RS_UNREG_DATA_OBJ_HPP

#include "unregDataObj.h"

int rsUnregDataObj( rsComm_t *rsComm, unregDataObj_t *unregDataObjInp );
int _rsUnregDataObj( rsComm_t *rsComm, unregDataObj_t *unregDataObjInp );

#endif
