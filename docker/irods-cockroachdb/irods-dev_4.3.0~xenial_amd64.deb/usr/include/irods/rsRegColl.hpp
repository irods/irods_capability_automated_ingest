#ifndef RS_REG_COLL_HPP
#define RS_REG_COLL_HPP

#include "rcConnect.h"
#include "dataObjInpOut.h"

int rsRegColl( rsComm_t *rsComm, collInp_t *regCollInp );
int _rsRegColl( rsComm_t *rsComm, collInp_t *regCollInp );

#endif
