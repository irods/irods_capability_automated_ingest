#ifndef SUB_STRUCT_FILE_CREATE_H__
#define SUB_STRUCT_FILE_CREATE_H__

#include "rcConnect.h"
#include "objInfo.h"

int rcSubStructFileCreate( rcComm_t *conn, subFile_t *subFile );

#endif
