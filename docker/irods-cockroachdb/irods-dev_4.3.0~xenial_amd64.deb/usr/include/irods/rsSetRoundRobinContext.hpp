#ifndef RS_SET_ROUND_ROBIN_CONTEXT_HPP
#define RS_SET_ROUND_ROBIN_CONTEXT_HPP

#include "rodsDef.h"
#include "rcConnect.h"
#include "set_round_robin_context.h"

int rsSetRoundRobinContext(rsComm_t*,setRoundRobinContextInp_t*);

#endif
