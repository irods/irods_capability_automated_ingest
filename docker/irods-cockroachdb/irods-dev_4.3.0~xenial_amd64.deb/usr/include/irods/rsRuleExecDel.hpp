#ifndef RS_RULE_EXEC_DEL_HPP
#define RS_RULE_EXEC_DEL_HPP

#include "ruleExecDel.h"

int rsRuleExecDel( rsComm_t *rsComm, ruleExecDelInp_t *ruleExecDelInp );
int _rsRuleExecDel( rsComm_t *rsComm, ruleExecDelInp_t *ruleExecDelInp );

#endif
