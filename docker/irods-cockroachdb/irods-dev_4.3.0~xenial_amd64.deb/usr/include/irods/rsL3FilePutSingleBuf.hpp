#ifndef RS_L3_FILE_PUT_SINGLE_BUF_HPP
#define RS_L3_FILE_PUT_SINGLE_BUF_HPP

#include "rodsDef.h"
#include "rcConnect.h"

int rsL3FilePutSingleBuf( rsComm_t *rsComm, int *l1descInx, bytesBuf_t *dataObjInBBuf );

#endif
