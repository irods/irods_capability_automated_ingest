#ifndef RS_EXEC_RULE_EXPRESSION_HPP
#define RS_EXEC_RULE_EXPRESSION_HPP

#include "exec_rule_expression.h"

int rsExecRuleExpression(rsComm_t*,exec_rule_expression_t*);


#endif
