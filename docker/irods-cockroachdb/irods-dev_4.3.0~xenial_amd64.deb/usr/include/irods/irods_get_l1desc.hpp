#ifndef __IRODS_GET_L1DESC_HPP__
#define __IRODS_GET_L1DESC_HPP__

#include "objDesc.hpp"

namespace irods {

    l1desc_t& get_l1desc( int );

}; // namespace irds

#endif // __IRODS_GET_L1DESC_HPP__

