#ifndef RS_GENERAL_ADMIN_HPP
#define RS_GENERAL_ADMIN_HPP

#include "rcConnect.h"
#include "generalAdmin.h"

int rsGeneralAdmin( rsComm_t *rsComm, generalAdminInp_t *generalAdminInp );
int _rsGeneralAdmin( rsComm_t *rsComm, generalAdminInp_t *generalAdminInp );

#endif
