#ifndef SUB_STRUCT_FILE_TRUNCATE_H__
#define SUB_STRUCT_FILE_TRUNCATE_H__

#include "rcConnect.h"
#include "objInfo.h"

int rcSubStructFileTruncate( rcComm_t *conn, subFile_t *subStructFileTruncateInp );

#endif
