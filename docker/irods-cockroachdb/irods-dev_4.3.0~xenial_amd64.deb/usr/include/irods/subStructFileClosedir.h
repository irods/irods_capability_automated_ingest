#ifndef SUB_STRUCT_FILE_CLOSEDIR_H__
#define SUB_STRUCT_FILE_CLOSEDIR_H__

#include "rcConnect.h"
#include "subStructFileRead.h"

int rcSubStructFileClosedir( rcComm_t *conn, subStructFileFdOprInp_t *subStructFileClosedirInp );

#endif
