#ifndef IRODS_VERSION_H__
#define IRODS_VERSION_H__

#define IRODS_VERSION_MAJOR             4
#define IRODS_VERSION_MINOR             3
#define IRODS_VERSION_PATCHLEVEL        0

#define IRODS_VERSION_INTEGER           (4*1000000 + 3*1000 + 0)

#endif  // IRODS_VERSION_H__
