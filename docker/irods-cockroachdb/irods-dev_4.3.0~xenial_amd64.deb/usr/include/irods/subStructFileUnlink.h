#ifndef SUB_STRUCT_FILE_UNLINK_H__
#define SUB_STRUCT_FILE_UNLINK_H__

#include "rcConnect.h"
#include "objInfo.h"

int rcSubStructFileUnlink( rcComm_t *conn, subFile_t *subFile );

#endif
