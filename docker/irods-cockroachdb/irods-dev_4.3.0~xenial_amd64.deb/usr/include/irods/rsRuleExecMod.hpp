#ifndef RS_RULE_EXEC_MOD_HPP
#define RS_RULE_EXEC_MOD_HPP

#include "rcConnect.h"
#include "ruleExecMod.h"

int rsRuleExecMod( rsComm_t *rsComm, ruleExecModInp_t *ruleExecModInp );
int _rsRuleExecMod( rsComm_t *rsComm, ruleExecModInp_t *ruleExecModInp );

#endif
