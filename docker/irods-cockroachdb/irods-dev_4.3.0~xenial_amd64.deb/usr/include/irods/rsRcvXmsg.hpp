#ifndef RS_RCV_XMSG_HPP
#define RS_RCV_XMSG_HPP

#include "rcConnect.h"
#include "rodsXmsg.h"

int rsRcvXmsg( rsComm_t *rsComm, rcvXmsgInp_t *rcvXmsgInp, rcvXmsgOut_t **rcvXmsgOut );

#endif
