#ifndef RS_AUTH_CHECK_HPP
#define RS_AUTH_CHECK_HPP

#include "authCheck.h"

int rsAuthCheck( rsComm_t *rsComm, authCheckInp_t *authCheckInp, authCheckOut_t **authCheckOut );

#endif
