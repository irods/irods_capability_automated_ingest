#ifndef __IRODS_SERVER_API_TABLE_HPP__
#define __IRODS_SERVER_API_TABLE_HPP__

#include "apiHandler.hpp"

namespace irods {

    api_entry_table& get_server_api_table();

}; // namespace irods

#endif // __IRODS_SERVER_API_TABLE_HPP__


