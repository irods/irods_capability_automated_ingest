#ifndef SUB_STRUCT_FILE_MKDIR_H__
#define SUB_STRUCT_FILE_MKDIR_H__

#include "rcConnect.h"
#include "objInfo.h"

int rcSubStructFileMkdir( rcComm_t *conn, subFile_t *subFile );

#endif
