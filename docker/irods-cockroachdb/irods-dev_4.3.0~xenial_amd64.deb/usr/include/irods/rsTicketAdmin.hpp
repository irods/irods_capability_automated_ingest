#ifndef RS_TICKET_ADMIN_HPP
#define RS_TICKET_ADMIN_HPP

#include "rcConnect.h"
#include "ticketAdmin.h"

int rsTicketAdmin( rsComm_t *rsComm, ticketAdminInp_t *ticketAdminInp );
int _rsTicketAdmin( rsComm_t *rsComm, ticketAdminInp_t *ticketAdminInp );

#endif
