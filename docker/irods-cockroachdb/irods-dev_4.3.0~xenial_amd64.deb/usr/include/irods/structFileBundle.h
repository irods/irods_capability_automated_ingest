#ifndef STRUCT_FILE_BUNDLE_H__
#define STRUCT_FILE_BUNDLE_H__

#include "rcConnect.h"
#include "structFileExtAndReg.h"

int rcStructFileBundle( rcComm_t *conn, structFileExtAndRegInp_t *structFileBundleInp );

#endif
