#ifndef RS_SSL_END_HPP
#define RS_SSL_END_HPP

#include "rcConnect.h"
#include "sslEnd.h"

int rsSslEnd( rsComm_t *rsComm, sslEndInp_t *sslEndInp );

#endif
