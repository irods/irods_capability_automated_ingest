#ifndef RS_READ_COLLECTION_HPP
#define RS_READ_COLLECTION_HPP

#include "rcConnect.h"
#include "miscUtil.h"

int rsReadCollection( rsComm_t *rsComm, int *handleInxInp, collEnt_t **collEnt );

#endif
