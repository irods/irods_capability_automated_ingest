#ifndef RS_CLOSE_COLLECTION_HPP
#define RS_CLOSE_COLLECTION_HPP

#include "objInfo.h"
#include "dataObjInpOut.h"
#include "rcConnect.h"

int rsCloseCollection( rsComm_t *rsComm, int *handleInxInp );

#endif
