#ifndef SUB_STRUCT_FILE_OPENDIR_H__
#define SUB_STRUCT_FILE_OPENDIR_H__

#include "objInfo.h"
#include "rcConnect.h"

int rcSubStructFileOpendir( rcComm_t *conn, subFile_t *subFile );

#endif
