#ifndef SUB_STRUCT_FILE_RMDIR_H__
#define SUB_STRUCT_FILE_RMDIR_H__

#include "rcConnect.h"
#include "objInfo.h"

int rcSubStructFileRmdir( rcComm_t *conn, subFile_t *subFile );

#endif
