#ifndef SUB_STRUCT_FILE_GET_H__
#define SUB_STRUCT_FILE_GET_H__

#include "rcConnect.h"
#include "objInfo.h"
#include "rodsDef.h"

int rcSubStructFileGet( rcComm_t *conn, subFile_t *subFile, bytesBuf_t *subFileGetOutBBuf );

#endif
