#ifndef RS_MOD_A_V_U_METADATA_HPP
#define RS_MOD_A_V_U_METADATA_HPP

#include "modAVUMetadata.h"

int rsModAVUMetadata( rsComm_t *rsComm, modAVUMetadataInp_t *modAVUMetadataInp );
int _rsModAVUMetadata( rsComm_t *rsComm, modAVUMetadataInp_t *modAVUMetadataInp );

#endif
