#ifndef RS_I_E_S_CLIENT_HINTS_HPP
#define RS_I_E_S_CLIENT_HINTS_HPP

#include "ies_client_hints.h"

int rsIESClientHints(rsComm_t* server_comm_ptr, bytesBuf_t** json_response);

#endif
