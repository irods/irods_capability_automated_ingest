#ifndef RS_SEND_XMSG_HPP
#define RS_SEND_XMSG_HPP

#include "rcConnect.h"
#include "rodsXmsg.h"

int rsSendXmsg( rsComm_t *rsComm, sendXmsgInp_t *sendXmsgInp );

#endif
