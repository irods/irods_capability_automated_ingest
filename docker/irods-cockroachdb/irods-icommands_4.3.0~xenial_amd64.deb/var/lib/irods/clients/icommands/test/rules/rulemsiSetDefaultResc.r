acSetRescSchemeForCreate {
  msiSetNoDirectRescInp("testResc"); 
  msiSetDefaultResc("demoResc","preferred");
  msiSetRescSortScheme("default");
}
