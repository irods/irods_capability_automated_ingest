acSetVaultPathPolicy {msiSetGraftPathScheme("no","1");}
