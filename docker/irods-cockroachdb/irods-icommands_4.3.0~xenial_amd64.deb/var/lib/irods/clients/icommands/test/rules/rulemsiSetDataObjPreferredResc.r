acPreProcForDataObjOpen {msiSetDataObjPreferredResc("demoResc%testResc");}
