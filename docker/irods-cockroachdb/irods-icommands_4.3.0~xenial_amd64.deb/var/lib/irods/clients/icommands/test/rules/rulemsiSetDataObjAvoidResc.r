acPreProcForDataObjOpen {msiSetDataObjAvoidResc("demoResc");}
