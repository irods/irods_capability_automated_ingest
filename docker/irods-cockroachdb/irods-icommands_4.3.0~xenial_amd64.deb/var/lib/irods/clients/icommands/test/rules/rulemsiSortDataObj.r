acPreProcForDataObjOpen {
  msiSortDataObj("byRescClass");
  msiStageDataObj("demoResc");
}
