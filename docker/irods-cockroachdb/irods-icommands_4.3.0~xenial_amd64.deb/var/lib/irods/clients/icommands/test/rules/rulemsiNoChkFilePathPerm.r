acNoChkFilePathPerm {
#No arguments
  msiNoChkFilePathPerm;
}
